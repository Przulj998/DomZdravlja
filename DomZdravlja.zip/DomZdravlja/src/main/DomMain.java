package main;




import domzdravlja.DomZdravlja;
import korisnici.Lekar;
import korisnici.MedicinskaSestra;
import korisnici.Pacijent;
import korisnici.Pregled;
import korisnici.ZdravstvenaKnjizica;



public class DomMain{
	private static String PREGLED_FAJL = "Pregled.txt";
	private static String LEKAR_FAJL = "Lekar.txt";
	private static String MEDICINSKASESTRA_FAJL = "MedicinskaSestra.txt";
	private static String PACIJENTI_FAJL = "Pacijenti.txt";
	private static String ZDRAVSTVENAKNJIZICA_FAJL = "ZdravstvenaKnjizica.txt";



	public static void main(String[] args) {
		DomZdravlja domzdravlja = new DomZdravlja();
	
		domzdravlja.ucitajMedicinskaSestra(MEDICINSKASESTRA_FAJL);
		domzdravlja.ucitajPacijent(PACIJENTI_FAJL);
		domzdravlja.ucitajLekare(LEKAR_FAJL);
		domzdravlja.ucitajZdravstvenaKnjizica(ZDRAVSTVENAKNJIZICA_FAJL);
		domzdravlja.ucitajPregled(PREGLED_FAJL);
	
		
		System.out.println("PODACI UCITANI IZ DATOTEKA:");
		System.out.println("----------------------------------------------");
		ispisiSvePodatke(domzdravlja);
		System.out.println("----------------------------------------------");
		
		
		System.out.println("Dodavanje test podataka...");
		Lekar testL = new Lekar("Srdjan", "Przulj", "9999999999999","m","Petrovska 133","999999999","Przulj","99999","hirurg", 150632, null);
		domzdravlja.dodajLekara(testL);
		System.out.println(testL);

		MedicinskaSestra testM = new MedicinskaSestra("Ivona", "Ivkovic", "3333333333333","f","Adresa3","333333333","Ika","33333", "Med. sestra", 100500, null, false);
		domzdravlja.dodajMedicinskaSestra(testM);
		System.out.println(testM);
		
		Pacijent testP = new Pacijent("Perica", "Beanic", "5555555555555", "m", "Pribojski put", "555555555", "Bean", "55555");
		domzdravlja.dodajPacijent(testP);
		System.out.println(testP);
		
		ZdravstvenaKnjizica testZ = new ZdravstvenaKnjizica(9, "19.12.2019", null);
		domzdravlja.dodajZdravstvenaKnjizica(testZ);
		System.out.println(testZ);
		
		Pregled testPr = new Pregled("02.10.2019 19:15", "A9", "ORL", null, null, null, null);
		domzdravlja.dodajPregled(testPr);
		System.out.println(testPr);
		
		System.out.println("Snimanje dodatih podataka...");
		domzdravlja.snimiLekara(LEKAR_FAJL);
		domzdravlja.snimiMedicinskaSestra(MEDICINSKASESTRA_FAJL);
		domzdravlja.snimiPacijenta(PACIJENTI_FAJL);
		domzdravlja.snimiZdravstvenaKnjizica(ZDRAVSTVENAKNJIZICA_FAJL);
		domzdravlja.snimiPregled(PREGLED_FAJL);
	
	}
	
		public static void ispisiSvePodatke(DomZdravlja domzdravlja) {
			for(Lekar lekar : domzdravlja.getLekar()) {
				System.out.println(lekar + "\n");
			}
			
			for(MedicinskaSestra ms : domzdravlja.getMedicinskaSestra()) {
				System.out.println(ms + "\n");
			}
			
			for(Pacijent pacijenti : domzdravlja.getPacijent()) {
				System.out.println(pacijenti + "\n");
			}
			
			for(ZdravstvenaKnjizica zk : domzdravlja.getZdravstvenaKnjizica()) {
				System.out.println(zk + "\n");
			}
			
			for(Pregled p : domzdravlja.getPregled()) {
				System.out.println(p + "\n");
			}
		
		}
}
