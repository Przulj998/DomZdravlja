package domzdravlja;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import fajlovi.Ocitavanje;
import korisnici.Lekar;
import korisnici.MedicinskaSestra;
import korisnici.Pacijent;
import korisnici.Pregled;
import korisnici.ZdravstvenaKnjizica;



public class DomZdravlja {
	
	private static ArrayList<Lekar> lekari = new ArrayList<Lekar>();
	private static ArrayList<Pacijent> pacijenti = new ArrayList<Pacijent>();
	private static ArrayList<MedicinskaSestra> ms = new ArrayList<MedicinskaSestra>();
	private static ArrayList<ZdravstvenaKnjizica> zk = new ArrayList<ZdravstvenaKnjizica>();
	private static ArrayList<Pregled> pr = new ArrayList<Pregled>();
	
	

	public ArrayList<Lekar> getLekar() {
		return lekari;
	}

	public void dodajLekara(Lekar lekari) {
		DomZdravlja.lekari.add(lekari);
	}
	
	public static void unosLekara() {
		System.out.print("JMBG Lekara:");
		String jmbgL= Ocitavanje.ocitajTekst();
		
		Lekar le = new Lekar(jmbgL);
		lekari.add(le);
		
		}
	

	public void obrisiLekara(Lekar lekari) {
		DomZdravlja.lekari.remove(lekari);
	}
	

	
	
	public static void izbrisiLekara(){
		Lekar le = null;
		System.out.print("Unesi jmbg lekara:");
		String jm = Ocitavanje.ocitajTekst();
		le = nadjiLekarajm(jm);
		if (le == null)
			System.out.println("Lekar sa jmbg-om " + jm
					+ " ne postoji");
		DomZdravlja.lekari.remove(le);
	}
	
	
	public static Lekar nadjiLekara() {
		Lekar le = null;
		System.out.print("Unesi jmbg lekara:");
		String jm = Ocitavanje.ocitajTekst();
		le = nadjiLekarajm(jm);
		if (le == null)
			System.out.println("Lekar sa jmbg-om " + jm
					+ " ne postoji");
		return le;
	}

	public static Lekar nadjiLekarajm(String jm) {
		Lekar le = null;
		for (int i = 0; i < lekari.size(); i++) {
			Lekar lek = lekari.get(i);
			if (lek.getJmbg() ==jm) {
				le = lek;
				break;
			}
		}
		return le;
	}
	
	public static void izmenaLekara() {
		Lekar le = nadjiLekara();
		if(le != null){
			System.out.print("Unesi novu adresu za lekara :");
			String leNovaAdresa = Ocitavanje.ocitajTekst();
			le.setAdresa(leNovaAdresa);

		}
	}
	
	public void ucitajLekare(String imeFajla) {
		try {
			File file = new File("src/fajlovi/" + imeFajla);
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String line;
			while ((line = reader.readLine()) != null) {
				String[] split = line.split("\\|");
				String ime = split[0];
				String prezime = split[1];
				String jmbg = split[2];
				String pol = split[3];
				String adresa = split[4];
				String brojTelefona = split[5];
				String korisnickoIme = split[6];
				String lozinka = split[7];
			Lekar le = new Lekar(ime, prezime, jmbg, pol, adresa, brojTelefona, korisnickoIme, lozinka, null, 0, null);
				lekari.add(le);
				
			}
			reader.close();
		} catch (Exception e) {
			System.out.println("Greska prilikom ucitvanja lekara");
			e.printStackTrace();
		}
	}
	
	public void snimiLekara(String imeFajla) {
		try {
			File file = new File("src/fajlovi/" + imeFajla);
			String content = "";
			for (Lekar lekar : lekari) {
				content += lekar.getIme() + "|" + lekar.getPrezime() + "|"
						+ lekar.getJmbg() + "|" + lekar.getPol() + "|" + "|"
						+ lekar.getAdresa() + "|" + lekar.getBrojTelefona() + "|"
						+ lekar.getKorisnickoIme() + "|" + lekar.getLozinka() + "|" + "\n";
			}
			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			writer.write(content);
			writer.close();
		} catch (IOException e) {
			System.out.println("Greska prilikom snimanja lekara.");
		}
	}
	

	public ArrayList<MedicinskaSestra> getMedicinskaSestra() {
		return ms;
	}

	public void dodajMedicinskaSestra(MedicinskaSestra ms) {
		DomZdravlja.ms.add(ms);
	}
	
	public static void unosMedicinskaSestra() {
		System.out.print("JMBG MedicinskaSestraa:");
		String jmbgM= Ocitavanje.ocitajTekst();
		
		MedicinskaSestra me = new MedicinskaSestra(jmbgM);
		ms.add(me);
		
		}
	

	public void obrisiMedicinskaSestra(MedicinskaSestra ms) {
		DomZdravlja.ms.remove(ms);
	}
	

	
	
	public static void izbrisiMedicinskaSestra(){
		MedicinskaSestra me = null;
		System.out.print("Unesi jmbg ms:");
		String jm = Ocitavanje.ocitajTekst();
		me = nadjiMedicinskaSestrajm(jm);
		if (me == null)
			System.out.println("MedicinskaSestra sa jmbg-om " + jm
					+ " ne postoji");
		DomZdravlja.ms.remove(me);
	}
	
	

	public static MedicinskaSestra nadjiMedicinskaSestra() {
		MedicinskaSestra me = null;
		System.out.print("Unesi jmbg ms:");
		String jm = Ocitavanje.ocitajTekst();
		me = nadjiMedicinskaSestrajm(jm);
		if (me == null)
			System.out.println("MedicinskaSestra sa jmbg-om " + jm
					+ " ne postoji");
		return me;
	}

	public static MedicinskaSestra nadjiMedicinskaSestrajm(String jm) {
		MedicinskaSestra me = null;
		for (int i = 0; i < ms.size(); i++) {
			MedicinskaSestra med = ms.get(i);
			if (med.getJmbg() ==jm) {
				me = med;
				break;
			}
		}
		return me;
	}
	
	public static void izmenaMedicinskaSestra() {
		MedicinskaSestra me = nadjiMedicinskaSestra();
		if(me != null){
			System.out.print("Unesi novu adresu za ms :");
			String meNovaAdresa = Ocitavanje.ocitajTekst();
			me.setAdresa(meNovaAdresa);

		}
	}
	
	public void ucitajMedicinskaSestra(String imeFajla) {
		try {
			File file = new File("src/fajlovi/" + imeFajla);
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String line;
			while ((line = reader.readLine()) != null) {
				String[] split = line.split("\\|");
				String ime = split[0];
				String prezime = split[1];
				String jmbg = split[2];
				String pol = split[3];
				String adresa = split[4];
				String brojTelefona = split[5];
				String korisnickoIme = split[6];
				String lozinka = split[7];
			MedicinskaSestra me = new MedicinskaSestra(ime, prezime, jmbg, pol,  adresa, brojTelefona, korisnickoIme, lozinka, null, 0, null, false);
				ms.add(me);
				
			}
			reader.close();
		} catch (Exception e) {
			System.out.println("Greska prilikom ucitvanja ms");
			e.printStackTrace();
		}
	}
	
	public void snimiMedicinskaSestra(String imeFajla) {
		try {
			File file = new File("src/fajlovi/" + imeFajla);
			String content = "";
			for (MedicinskaSestra medicinskasestra : ms) {
				content += medicinskasestra.getIme() + "|" + medicinskasestra.getPrezime() + "|"
						+ medicinskasestra.getJmbg() + "|" + medicinskasestra.getPol() + "|" + "|"
						+ medicinskasestra.getAdresa() + "|" + medicinskasestra.getBrojTelefona() + "|"
						+ medicinskasestra.getKorisnickoIme() + "|" + medicinskasestra.getLozinka() + "|" + "\n" ;
			}
			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			writer.write(content);
			writer.close();
		} catch (IOException e) {
			System.out.println("Greska prilikom snimanja ms.");
		}
	}

	public ArrayList<Pacijent> getPacijent() {
		return pacijenti;
	}

	public void dodajPacijent(Pacijent pacijenti) {
		DomZdravlja.pacijenti.add(pacijenti);
	}
	
	public static void unosPacijenta() {
		System.out.print("JMBG Pacijenta:");
		String jmbgP= Ocitavanje.ocitajTekst();
		
		Pacijent pr = new Pacijent(jmbgP);
		pacijenti.add(pr);
		
		}
	

	public void obrisiPacijent(Pacijent pacijenti) {
		DomZdravlja.pacijenti.remove(pacijenti);
	}
	

	
	
	public static void izbrisiPacijenta(){
		Pacijent pa = null;
		System.out.print("Unesi jmbg pacijenta:");
		String jm = Ocitavanje.ocitajTekst();
		pa = nadjiPacijentjm(jm);
		if (pa == null)
			System.out.println("Pacijent sa jmbg-om " + jm
					+ " ne postoji");
		DomZdravlja.pacijenti.remove(pa);
	}
	
	
	public static Pacijent nadjiPacijenta() {
		Pacijent pa = null;
		System.out.print("Unesi jmbg pacijenta:");
		String jm = Ocitavanje.ocitajTekst();
		pa = nadjiPacijentjm(jm);
		if (pa == null)
			System.out.println("Pacijent sa jmbg-om " + jm
					+ " ne postoji");
		return pa;
	}

	public static Pacijent nadjiPacijentjm(String jm) {
		Pacijent pa = null;
		for (int i = 0; i < pacijenti.size(); i++) {
			Pacijent pac = pacijenti.get(i);
			if (pac.getJmbg() ==jm) {
				pa = pac;
				break;
			}
		}
		return pa;
	}
	
	public static void izmenaPacijenta() {
		Pacijent pa = nadjiPacijenta();
		if(pa != null){
			System.out.print("Unesi novu adresu za pacijenta :");
			String paNovaAdresa = Ocitavanje.ocitajTekst();
			pa.setAdresa(paNovaAdresa);

		}
	}
	
	public void ucitajPacijent(String imeFajla) {
		try {
			File file = new File("src/fajlovi/" + imeFajla);
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String line;
			while ((line = reader.readLine()) != null) {
				String[] split = line.split("\\|");
				String ime = split[0];
				String prezime = split[1];
				String jmbg = split[2];
				String pol = split[3];
				String adresa = split[4];
				String brojTelefona = split[5];
				String korisnickoIme = split[6];
				String lozinka = split[7];
			Pacijent pa = new Pacijent(ime, prezime, jmbg, pol, adresa, brojTelefona, korisnickoIme, lozinka);
				pacijenti.add(pa);
				
			}
			reader.close();
		} catch (Exception e) {
			System.out.println("Greska prilikom ucitvanja pacijenta");
			e.printStackTrace();
		}
	}
	
	public void snimiPacijenta(String imeFajla) {
		try {
			File file = new File("src/fajlovi/" + imeFajla);
			String content = "";
			for (Pacijent pacijent : pacijenti) {
				content += pacijent.getIme() + "|" + pacijent.getPrezime() + "|"
						+ pacijent.getJmbg() + "|" + pacijent.getPol() + "|" + "|"
						+ pacijent.getAdresa() + "|" + pacijent.getBrojTelefona() + "|"
						+ pacijent.getKorisnickoIme() + "|" + pacijent.getLozinka() + "|" + "\n";
			}
			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			writer.write(content);
			writer.close();
		} catch (IOException e) {
			System.out.println("Greska prilikom snimanja pacijenta.");
		}
	}

	public ArrayList<ZdravstvenaKnjizica> getZdravstvenaKnjizica() {
		return zk;
	}

	public void dodajZdravstvenaKnjizica(ZdravstvenaKnjizica zk) {
		DomZdravlja.zk.add(zk);
	}
	
	public static void unosZdravstvenaKnjizica(ZdravstvenaKnjizica zk) {
		DomZdravlja.zk.add(zk);
	}
	

	public void obrisiZdravstvenaKnjizica(ZdravstvenaKnjizica zk) {
		DomZdravlja.zk.remove(zk);
	}
	

	
	
	public static void izbrisiZdravstvenaKnjizica(){
		ZdravstvenaKnjizica zd = null;
		if (zd == null)
		DomZdravlja.zk.remove(zd);
	}
	
	public static void izmenaZdravstvenaKnjizica() {

	}
	
	public void ucitajZdravstvenaKnjizica(String imeFajla) {
		try {
			File file = new File("src/fajlovi/" + imeFajla);
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String line;
			while ((line = reader.readLine()) != null) {
				String[] split = line.split("\\|");
				String brojString = split[0];
				int broj = Integer.parseInt(brojString);
				String datum = split[1];
			ZdravstvenaKnjizica zd = new ZdravstvenaKnjizica(broj, datum, null);
				zk.add(zd);
				
			}
			reader.close();
		} catch (Exception e) {
			System.out.println("Greska prilikom ucitvanja knjizice");
			e.printStackTrace();
		}
	}
	
	public void snimiZdravstvenaKnjizica(String imeFajla) {
		try {
			File file = new File("src/fajlovi/" + imeFajla);
			String content = "";
			for (ZdravstvenaKnjizica zdravstvenaknjizica : zk) {
				content += zdravstvenaknjizica.getBroj() + "|" + zdravstvenaknjizica.getDatum() + "|"
					+ "\n";
			}
			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			writer.write(content);
			writer.close();
		} catch (IOException e) {
			System.out.println("Greska prilikom snimanja knjizice.");
		}
	}


	public ArrayList<Pregled> getPregled() {
		return pr;
	}

	public void dodajPregled(Pregled pr) {
		DomZdravlja.pr.add(pr);
	}
	
	public static void unosPregled(Pregled pr) {
		DomZdravlja.pr.add(pr);
	}
	

	public void obrisiPregled(Pregled pr) {
		DomZdravlja.pr.remove(pr);
	}
	

	public static void izbrisiPregled(){
		Pregled pre = null;
		if (pre == null)
		DomZdravlja.pr.remove(pre);
	}
	
	public static void izmenaPregled() {

	}
	
	public void ucitajPregled(String imeFajla) {
		try {
			File file = new File("src/fajlovi/" + imeFajla);
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String line;
			while ((line = reader.readLine()) != null) {
				String[] split = line.split("\\|");
				String termin = split[0];
				String soba = split[1];
				String opis = split[2];
			Pregled pre = new Pregled(termin, soba, opis, null, null, null, null);
				pr.add(pre);
				
			}
			reader.close();
		} catch (Exception e) {
			System.out.println("Greska prilikom ucitvanja pregleda");
			e.printStackTrace();
		}
	}
	
	public void snimiPregled(String imeFajla) {
		try {
			File file = new File("src/fajlovi/" + imeFajla);
			String content = "";
			for (Pregled pregled : pr) {
				content += pregled.getTermin() + "|" + pregled.getSoba() + "|"
					+ pregled.getOpis() + "|" + "\n";
			}
			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			writer.write(content);
			writer.close();
		} catch (IOException e) {
			System.out.println("Greska prilikom snimanja pregleda.");
		}
	}

	}


	

