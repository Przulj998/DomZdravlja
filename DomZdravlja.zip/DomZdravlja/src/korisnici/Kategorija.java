package korisnici;

public enum Kategorija {

	
	Prva,
	Druga,
	Treca;

	public static void fromInt(int a) {
	
			  

			    switch(a) {
			      case 1:
			        System.out.println("Prva kategorija osiguranja");
			        break;
			      case 2:
			         System.out.println("Druga kategorija osiguranja");
			        break;
			      case 3:
			        System.out.println("Treca kategorija osiguranja");
			        break;
			   
			    }
			  }
			}

