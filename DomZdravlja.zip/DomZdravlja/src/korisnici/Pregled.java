package korisnici;

import java.util.ArrayList;


public class Pregled {
	
	protected String termin;
	protected String soba;
	protected String opis;
	protected Status status;
	
	
	
	protected ArrayList<Lekar> lekari = new ArrayList<Lekar>();
	protected ArrayList<MedicinskaSestra> ms = new ArrayList<MedicinskaSestra>();
	protected ArrayList<Pacijent> pacijenti = new ArrayList<Pacijent>();
	
	
	public Pregled(String termin, String soba, String opis, Status status, ArrayList<Lekar> lekari,
			ArrayList<MedicinskaSestra> ms, ArrayList<Pacijent> pacijenti) {
		super();
		this.termin = termin;
		this.soba = soba;
		this.opis = opis;
		this.status = status;
		this.lekari = lekari;
		this.ms = ms;
		this.pacijenti = pacijenti;
	}

	public String getTermin() {
		return termin;
	}
	public void setTermin(String termin) {
		this.termin = termin;
	}
	public String getSoba() {
		return soba;
	}
	public void setSoba(String soba) {
		this.soba = soba;
	}
	public String getOpis() {
		return opis;
	}
	public void setOpis(String opis) {
		this.opis = opis;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public ArrayList<Lekar> getLekari() {
		return lekari;
	}
	public void setLekari(ArrayList<Lekar> lekari) {
		this.lekari = lekari;
	}
	public ArrayList<MedicinskaSestra> getMs() {
		return ms;
	}
	public void setMs(ArrayList<MedicinskaSestra> ms) {
		this.ms = ms;
	}
	public ArrayList<Pacijent> getPacijenti() {
		return pacijenti;
	}
	public void setPacijenti(ArrayList<Pacijent> pacijenti) {
		this.pacijenti = pacijenti;
	}
	
	
	@Override
	public String toString() {
		return "Pregled \ntermin: " + termin + "\nsoba: " + soba + "\nopis: " + opis + "\nstatus: " + status + "\nlekari: "
				+ lekari + "\nms: " + ms + "\npacijenti: " + pacijenti;
	}
	
	
	
	
	
	
	
}
