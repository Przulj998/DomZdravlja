package korisnici;

public enum SluzbaE {
	
	SluzbaOpsteMedicine,
	SluzbaZdravstveneZastiteDece, 
	StomatoloskaSluzba, 
	SluzbaZdravstveneZastiteRadnika, 
	Slu�baZaPravneIEkonomskePoslove, 
	SluzbaZaTehnickePoslove;

	public static void fromInt(int a) {
	
			  

			    switch(a) {
			      case 1:
			        System.out.println("SluzbaOpsteMedicine");
			        break;
			      case 2:
			         System.out.println("SluzbaZdravstveneZastiteDece");
			        break;
			      case 3:
			        System.out.println("StomatoloskaSluzba");
			        break;
			      case 4:
				    System.out.println("SluzbaZdravstveneZastiteRadnika");
				     break;
				  case 5:
				    System.out.println("Slu�baZaPravneIEkonomskePoslove");
				     break;
				  case 6:
				    System.out.println("SluzbaZaTehnickePoslove");
				     break;
				   
			    }
			  }
			}


	
	

