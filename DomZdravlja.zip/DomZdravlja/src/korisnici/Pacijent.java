package korisnici;

public class Pacijent extends Korisnik {

}
