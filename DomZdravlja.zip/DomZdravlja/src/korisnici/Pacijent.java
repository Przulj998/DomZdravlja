package korisnici;

public class Pacijent extends Korisnik {
	
	private Lekar lekar;
	private ZdravstvenaKnjizica zk;
	
	
	public Pacijent(Lekar lekar, ZdravstvenaKnjizica zk) {
		super();
		this.lekar = lekar;
		this.zk = zk;
	}

	public Pacijent() {}
	
	public Pacijent (String jmbg) {
		
		this.jmbg = jmbg;
	}



	public Pacijent(String ime, String prezime, String jmbg, String pol, String adresa, String brojTelefona,
			String korisnickoIme, String lozinka) {
		this.ime = ime;
		this.prezime = prezime;
		this.jmbg = jmbg;
		this.pol = pol;
		this.adresa = adresa;
		this.brojTelefona = brojTelefona;
		this.korisnickoIme = korisnickoIme;
		this.lozinka = lozinka;

	}




	public Lekar getLekar() {
		return lekar;
	}


	public void setLekar(Lekar lekar) {
		this.lekar = lekar;
	}


	public ZdravstvenaKnjizica getZk() {
		return zk;
	}


	public void setZk(ZdravstvenaKnjizica zk) {
		this.zk = zk;
	}


	@Override
	public String toString() {
		return "PACIJENT \nIme: " + ime + 
				"\nPrezime: " + prezime +
				"\nJmbg: " + jmbg +
				"\nPol: " + pol +
				"\nAdresa: " + adresa + 
				"\nBroj Telefona: " + brojTelefona +
				"\nKorisnicko Ime: " + korisnickoIme +
				"\nLozinka: " + lozinka +
				"\nlekar: " + lekar + 
				"\nzk: " + zk;
	
	}
	
}	