package korisnici;



public class MedicinskaSestra extends Korisnik{
	
	
	private String spec;
	private double plata;
	private SluzbaE sluzba;
	
	
	public MedicinskaSestra(String spec, double plata, SluzbaE sluzba, boolean admin) {
		super();
		this.spec = spec;
		this.plata = plata;
		this.sluzba = sluzba;
		this.admin = true;
	}


	public MedicinskaSestra () {}
	
	public MedicinskaSestra (String jmbg) {
		
		this.jmbg = jmbg;
	}

	public MedicinskaSestra(String ime, String prezime, String jmbg, String pol, String adresa, String brojTelefona,
			String korisnickoIme, String lozinka, String spec, double plata, SluzbaE sluzba, boolean admin) {
		this.ime = ime;
		this.prezime = prezime;
		this.jmbg = jmbg;
		this.pol = pol;
		this.adresa = adresa;
		this.brojTelefona = brojTelefona;
		this.korisnickoIme = korisnickoIme;
		this.lozinka = lozinka;	
		this.spec = spec;
		this.plata = plata;
		this.sluzba = sluzba;
		this.admin = admin;
	}


	public String getSpec() {
		return spec;
	}


	public void setSpec(String spec) {
		this.spec = spec;
	}


	public double getPlata() {
		return plata;
	}


	public void setPlata(double plata) {
		this.plata = plata;
	}


	public SluzbaE getSluzba() {
		return sluzba;
	}


	public void setSluzba(SluzbaE sluzba) {
		this.sluzba = sluzba;
	}


	@Override
	public String toString() {
		return "MEDICINSKA SESTRA \nIme: " + ime + 
				"\nPrezime: " + prezime +
				"\nJmbg: " + jmbg +
				"\nPol: " + pol +
				"\nAdresa: " + adresa + 
				"\nBroj Telefona: " + brojTelefona +
				"\nKorisnicko Ime: " + korisnickoIme +
				"\nLozinka: " + lozinka +
				"\nspec: " + spec + 
				"\nplata: " + plata + 
				"\nsluzba: " + sluzba +
				"\nadmin: " + admin;
	}	
	
	
}