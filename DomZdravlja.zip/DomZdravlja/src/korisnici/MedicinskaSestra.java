package korisnici;

public class MedicinskaSestra extends Korisnik{

}
