package korisnici;


	public enum Status {
		Zatra�en,
		Zakazan,
		Otkazan,
		Zavr�en;

	public static void fromInt(int a) {
	
			  

			    switch(a) {
			      case 1:
			        System.out.println("Zatra�en pregled");
			        break;
			      case 2:
			         System.out.println("Zakazan pregled");
			        break;
			      case 3:
			        System.out.println("Otkazan pregled");
			        break;
			      case 4:
				        System.out.println("Zavr�en pregled");
				        break;
			    }
			  }
			}