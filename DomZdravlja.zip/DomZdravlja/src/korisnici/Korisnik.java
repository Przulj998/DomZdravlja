package korisnici;

public abstract class Korisnik {

}
