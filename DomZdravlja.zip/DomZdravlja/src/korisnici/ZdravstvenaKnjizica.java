package korisnici;

public class ZdravstvenaKnjizica {
	private int broj;
	private String datum;
	private Kategorija kategorija;
	
	
	public ZdravstvenaKnjizica(int broj, String datum, Kategorija kategorija) {
		super();
		this.broj = broj;
		this.datum = datum;
		this.kategorija = kategorija;
	}

	public void ZdravstvenaKnjizica1(int broj, String datum, Kategorija kategorija) {
		this.broj = broj;
		this.datum = datum;
		this.kategorija = kategorija;
	}

	public int getBroj() {
		return broj;
	}

	public void setBroj(int broj) {
		this.broj = broj;
	}

	public String getDatum() {
		return datum;
	} 

	public void setDatum(String datum) {
		this.datum = datum;
	}
	
	public Kategorija getKategorija() {
		return kategorija;
	} 

	public void setKategorija(Kategorija kategorija) {
		this.kategorija = kategorija;
	}



	@Override
	public String toString() {
		return "ZdravstvenaKnjizica \nbroj: " + broj + "\ndatum: " + datum + "\nkategorija: " + kategorija;
	}

	
}
