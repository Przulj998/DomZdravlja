package korisnici;

public class Lekar extends Korisnik {

}
